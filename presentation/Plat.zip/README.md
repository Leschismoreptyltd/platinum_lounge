"# platinum_lounge" 
